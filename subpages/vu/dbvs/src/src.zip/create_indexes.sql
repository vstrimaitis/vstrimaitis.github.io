CREATE UNIQUE INDEX User_Email 	ON vyst2902.User(Email);
CREATE INDEX User_Username 		ON vyst2902.User(Username);
CREATE INDEX Post_Title 		ON vyst2902.Post(Title);