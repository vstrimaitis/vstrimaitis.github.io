DROP VIEW vyst2902.Posts;
DROP VIEW vyst2902.Comments;