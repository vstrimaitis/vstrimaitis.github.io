DROP TABLE vyst2902.User_Skills;
DROP TABLE vyst2902.Programming_Language;
DROP TABLE vyst2902.Saved_Posts;
DROP TABLE vyst2902.Comment;
DROP TABLE vyst2902.Post;
DROP TABLE vyst2902.Rated_Entities;
DROP TABLE vyst2902.Ratable_Entity;
DROP TABLE vyst2902.User;