package vyst2902.ui;

enum RowType {
	HEADER,
	REGULAR,
	FOOTER
}
